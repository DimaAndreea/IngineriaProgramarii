-- USER:
INSERT INTO USERS (role, username, password_hash, phone_number, email, level, xp, travel_coins)
VALUES
    ('ADMIN',   'AdminTest', 'admin',  '0744123123', 'admin@test.com', 1, 0, 0),
    ('GUIDE',   'GhidTest', 'guide',  '0712345678', 'guide@test.com', 3, 500, 0),
    ('TOURIST', 'TuristTest', 'tourist', '0722334455', 'tourist@test.com', 2, 200, 50);