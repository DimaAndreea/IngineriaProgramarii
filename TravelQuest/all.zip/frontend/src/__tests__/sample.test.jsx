import { describe, it, expect } from "vitest";

describe("Sample test", () => {
  it("should pass", () => {
    expect(1 + 1).toBe(2);
  });
});
