## Subtask 2 - login & register

# Register
## Browser request
![img_3.png](img_3.png)

## Postman request
![img.png](img.png)

# Login Successful
## Browser request
![img_4.png](img_4.png)

## Postman request
![img_1.png](img_1.png)

# Login - Invalid Credentials
![img_2.png](img_2.png)





