package com.travelquest.travelquestbackend.service;

import com.travelquest.travelquestbackend.dto.MissionValidationDto;
import com.travelquest.travelquestbackend.model.Mission;
import com.travelquest.travelquestbackend.model.UserMission;
import com.travelquest.travelquestbackend.repository.UserMissionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class MissionValidationService {

    private final UserMissionRepository userMissionRepository;

    public MissionValidationService(UserMissionRepository userMissionRepository) {
        this.userMissionRepository = userMissionRepository;
    }

    /**
     * Marchează misiunea ca COMPLETED dacă s-a atins progresul necesar.
     * Nu acordă puncte și nu creează claim.
     */
    @Transactional
    public MissionValidationDto validateMissionCompletion(Long userId, Long missionId) {
        // obținem UserMission
        UserMission userMission = userMissionRepository
                .findByUserIdAndMissionId(userId, missionId)
                .orElseThrow(() -> new EntityNotFoundException("UserMission not found"));

        Mission mission = userMission.getMission();
        boolean canComplete = userMission.getProgressValue() >= mission.getTargetValue();

        if (!canComplete) {
            // progres insuficient, rămâne IN_PROGRESS
            userMission.setState("IN_PROGRESS");
            userMissionRepository.save(userMission);

            System.out.println("=== MISSION NOT YET COMPLETE ===");
            System.out.println("User ID: " + userId + ", Mission ID: " + missionId);
            System.out.println("Progress: " + userMission.getProgressValue() + "/" + mission.getTargetValue());
            System.out.println("===============================");

            return new MissionValidationDto(false, 0);
        }

        // marchează ca COMPLETED
        userMission.setState("COMPLETED");
        userMission.setCompletedAt(LocalDateTime.now());
        userMissionRepository.save(userMission);

        System.out.println("=== MISSION COMPLETED ===");
        System.out.println("User ID: " + userId + ", Mission ID: " + missionId + ", Title: " + mission.getTitle());
        System.out.println("Progress: " + userMission.getProgressValue() + "/" + mission.getTargetValue());
        System.out.println("Status: COMPLETED (claim pending manual action)");
        System.out.println("==========================");

        return new MissionValidationDto(true, 0); // puncte = 0, claim manual ulterior
    }
}
