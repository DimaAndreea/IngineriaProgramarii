package com.travelquest.travelquestbackend.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.travelquest.travelquestbackend.model.Mission;
import com.travelquest.travelquestbackend.model.MissionParticipation;
import com.travelquest.travelquestbackend.model.UserMission;
import com.travelquest.travelquestbackend.repository.ItineraryRepository;
import com.travelquest.travelquestbackend.repository.SubmissionRepository;
import com.travelquest.travelquestbackend.repository.UserMissionItineraryRepository;
import com.travelquest.travelquestbackend.repository.UserMissionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class MissionProgressService {

    private final UserMissionRepository userMissionRepository;
    private final UserMissionItineraryRepository userMissionItineraryRepository;
    private final SubmissionRepository submissionRepository;
    private final ItineraryRepository itineraryRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public MissionProgressService(
            UserMissionRepository userMissionRepository,
            UserMissionItineraryRepository userMissionItineraryRepository,
            SubmissionRepository submissionRepository,
            ItineraryRepository itineraryRepository
    ) {
        this.userMissionRepository = userMissionRepository;
        this.userMissionItineraryRepository = userMissionItineraryRepository;
        this.submissionRepository = submissionRepository;
        this.itineraryRepository = itineraryRepository;
    }

    /**
     * Actualizează progresul utilizatorului pentru o misiune.
     * Dacă progresul ajunge la 100%, misiunea se marchează ca COMPLETED,
     * dar claim-ul rămâne manual.
     */
    @Transactional
    public void updateProgressForUser(Long userId, Long missionId) {

        UserMission userMission = userMissionRepository
                .findByUserIdAndMissionId(userId, missionId)
                .orElseThrow(() -> new RuntimeException("UserMission not found"));

        if ("COMPLETED".equals(userMission.getState())) {
            System.out.println("UserMission already COMPLETED for userId=" + userId + ", missionId=" + missionId);
            return;
        }

        Mission mission = userMission.getMission();

        int currentValue = calculateCurrentValue(userId, userMission, mission);
        int targetValue = extractTargetFromParams(mission.getParamsJson());
        int progressPercent = calculateProgressPercent(currentValue, targetValue);

        // actualizează progresul
        userMission.setProgressValue(progressPercent);
        userMissionRepository.save(userMission);

        System.out.println("=== MISSION PROGRESS UPDATED ===");
        System.out.println("User ID: " + userId);
        System.out.println("Mission ID: " + missionId + ", Title: " + mission.getTitle());
        System.out.println("Current Value: " + currentValue + ", Target: " + targetValue);
        System.out.println("Progress: " + progressPercent + "%");
        System.out.println("Status before update: " + userMission.getState());
        System.out.println("===============================");

        // dacă progresul ajunge la 100%, marcare COMPLETED
        if (progressPercent >= 100) {
            userMission.setState("COMPLETED");
            userMission.setCompletedAt(LocalDateTime.now());
            userMissionRepository.save(userMission);

            System.out.println("=== MISSION COMPLETED ===");
            System.out.println("User ID: " + userId);
            System.out.println("Mission ID: " + missionId + ", Title: " + mission.getTitle());
            System.out.println("Progress: " + progressPercent + "%");
            System.out.println("Status: COMPLETED (claim pending manual action)");
            System.out.println("==========================");
        }
    }

    // ==========================
    // CALCUL CURRENT VALUE
    // ==========================
    private int calculateCurrentValue(Long userId, UserMission userMission, Mission mission) {
        switch (mission.getType()) {

            case "TOURIST_JOIN_ITINERARY_COUNT":
                return userMissionItineraryRepository.countByUserMissionId(userMission.getId());

            case "TOURIST_APPROVED_SUBMISSIONS_COUNT":
                return submissionRepository.countApprovedByUser(userId);

            case "TOURIST_JOIN_ITINERARY_CATEGORY_COUNT": {
                String category = extractCategoryFromParams(mission.getParamsJson());
                return userMissionItineraryRepository.countByUserMissionIdAndCategory(userMission.getId(), category);
            }

            case "TOURIST_APPROVED_SUBMISSIONS_CATEGORY_COUNT": {
                String category = extractCategoryFromParams(mission.getParamsJson());
                return submissionRepository.countApprovedByUserAndCategory(userId, category);
            }

            case "TOURIST_APPROVED_SUBMISSIONS_SAME_ITINERARY_COUNT": {
                Long itineraryId = extractItineraryIdFromParams(mission.getParamsJson());
                return submissionRepository.countApprovedByUserAndItinerary(userId, itineraryId);
            }

            case "GUIDE_PUBLISH_ITINERARY_COUNT":
                return itineraryRepository.countPublishedByUser(userId);

            case "GUIDE_ITINERARY_CATEGORY_PARTICIPANTS_COUNT": {
                String category = extractCategoryFromParams(mission.getParamsJson());
                return itineraryRepository.countParticipantsInCategoryByUser(userId, category);
            }

            case "GUIDE_EVALUATE_SUBMISSIONS_COUNT":
                return submissionRepository.countEvaluatedByUser(userId);

            default:
                return 0;
        }
    }

    // ==========================
    // PROGRESS CALCULATION
    // ==========================
    private int calculateProgressPercent(int current, int target) {
        if (target <= 0) return 0;
        return Math.min(100, (current * 100) / target);
    }

    // ==========================
    // PARAMS JSON HELPERS
    // ==========================
    private int extractTargetFromParams(String paramsJson) {
        try {
            JsonNode node = objectMapper.readTree(paramsJson);
            return node.has("target") ? node.get("target").asInt() : 1;
        } catch (Exception e) {
            return 1;
        }
    }

    private String extractCategoryFromParams(String paramsJson) {
        try {
            JsonNode node = objectMapper.readTree(paramsJson);
            return node.has("category") ? node.get("category").asText() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private Long extractItineraryIdFromParams(String paramsJson) {
        try {
            JsonNode node = objectMapper.readTree(paramsJson);
            return node.has("itinerary") ? node.get("itinerary").asLong() : null;
        } catch (Exception e) {
            return null;
        }
    }
}
