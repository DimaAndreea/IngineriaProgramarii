import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  getItineraryById,
  updateItinerary,
  deleteItinerary,
  joinItinerary,
} from "../services/itineraryService";
import { useAuth } from "../context/AuthContext";
import ItineraryForm from "../components/itineraries/ItineraryForm";
import "./ItineraryDetailsPage.css";

export default function ItineraryDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { userId, role } = useAuth();
  const isTourist = role === "tourist";

  const [itinerary, setItinerary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [joinMessage, setJoinMessage] = useState("");
  const [joinError, setJoinError] = useState("");

  const isCreator =
    itinerary?.creator?.id && Number(itinerary.creator.id) === Number(userId);

  const rawStatus = itinerary?.status?.toUpperCase();
  const displayStatus =
    rawStatus === "APPROVED"
      ? "Published"
      : rawStatus === "PENDING"
      ? "Pending"
      : rawStatus === "REJECTED"
      ? "Rejected"
      : rawStatus || "";

  const statusClass =
    rawStatus === "APPROVED"
      ? "published"
      : rawStatus === "PENDING"
      ? "pending"
      : rawStatus === "REJECTED"
      ? "rejected"
      : "";

  const canEditThis = isCreator && rawStatus === "PENDING";
  const canDeleteThis =
    isCreator && (rawStatus === "PENDING" || rawStatus === "REJECTED");
  const canJoinThis = isTourist && rawStatus === "APPROVED";

  // ======================
  // LOAD ITINERARY
  // ======================
  useEffect(() => {
    async function load() {
      try {
        const data = await getItineraryById(id);
        setItinerary(data);
      } catch (err) {
        console.error("Failed to load itinerary:", err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  // ======================
  // DELETE
  // ======================
  async function handleDelete() {
    if (!confirm("Are you sure you want to delete this itinerary?")) return;

    try {
      const realId =
        itinerary.id || itinerary.itineraryId || itinerary.itinerary_id;
      await deleteItinerary(realId);
      navigate("/itineraries");
    } catch (err) {
      console.error(err);
      alert("Delete failed.");
    }
  }

  // ======================
  // UPDATE
  // ======================
  async function handleUpdate(values) {
    const realId =
      itinerary.id || itinerary.itineraryId || itinerary.itinerary_id;

    try {
      const updated = await updateItinerary(realId, values);
      setItinerary(updated);
      setShowEditModal(false);
    } catch (err) {
      console.error(err);
      alert("Update failed.");
    }
  }

  // ======================
  // JOIN TOUR (TOURIST)
  // ======================
  async function handleJoin() {
    const realId =
      itinerary.id || itinerary.itineraryId || itinerary.itinerary_id;

    try {
      const message = await joinItinerary(realId);
      setJoinMessage(message || "Tour successfully joined!");
      setJoinError("");
    } catch (err) {
      setJoinError(err?.message || "Failed to join the tour");
      setJoinMessage("");
    }
  }

  if (loading) return <div className="loading">Loading...</div>;
  if (!itinerary) return <div className="error">Itinerary not found.</div>;

  const creatorId = itinerary?.creator?.id;
  const creatorName = itinerary?.creator?.username || "Guide";

  return (
    <div className="details-wrapper">
      {/* IMAGE */}
      <div className="details-gallery">
        <img className="gallery-main" src={itinerary.imageBase64} alt="Itinerary" />
      </div>

      {/* TITLE */}
      <h1 className="details-title">{itinerary.title}</h1>

      {/* META INFO */}
      <div className="details-meta-header">
        <span className="category-tag">{itinerary.category}</span>

        {!isTourist && (
          <span className={`status-tag ${statusClass}`}>{displayStatus}</span>
        )}

        {/* ✅ link către profilul ghidului */}
        <span className="author-tag">
          By:{" "}
          {creatorId ? (
            <Link className="author-link" to={`/guides/${creatorId}`}>
              {creatorName}
            </Link>
          ) : (
            creatorName
          )}
        </span>

        <span className="date-range">
          {itinerary.startDate} → {itinerary.endDate}
        </span>
      </div>

      {/* ABOUT CARD */}
      <div className="details-card big">
        <h2>About this activity</h2>
        <p className="details-description">{itinerary.description}</p>

        <div className="info-list">
          <p>
            <strong>Category:</strong> {itinerary.category}
          </p>
          {!isTourist && (
            <p>
              <strong>Status:</strong> {displayStatus}
            </p>
          )}
          <p>
            <strong>Price:</strong> {itinerary.price} RON
          </p>
        </div>

        {/* JOIN BUTTON – TOURIST */}
        {canJoinThis && (
          <div className="creator-action-row" style={{ marginTop: "20px" }}>
            <button
              className="soft-btn primary"
              onClick={handleJoin}
              style={{ width: "100%", justifyContent: "center" }}
            >
              Join tour
            </button>

            {joinMessage && <p className="join-success">{joinMessage}</p>}
            {joinError && <p className="join-error">{joinError}</p>}
          </div>
        )}

        {/* ACTIONS — EDIT & DELETE (creator) */}
        {(canEditThis || canDeleteThis) && (
          <div className="creator-action-row">
            {canEditThis && (
              <button className="soft-btn edit" onClick={() => setShowEditModal(true)}>
                Edit
              </button>
            )}
            {canDeleteThis && (
              <button className="soft-btn delete" onClick={handleDelete}>
                Delete
              </button>
            )}
          </div>
        )}
      </div>

      {/* LOCATIONS GRID */}
      <h2 className="section-title">Locations</h2>
      <div className="locations-grid">
        {itinerary.locations.map((loc, index) => (
          <div className="location-card grid-card" key={index}>
            <h3>Location #{index + 1}</h3>
            <p>
              <strong>Country:</strong> {loc.country}
            </p>
            <p>
              <strong>City:</strong> {loc.city}
            </p>
            <p className="objectives-label">
              <strong>Objectives:</strong>
            </p>
            <ul className="objectives-list">
              {loc.objectives.map((obj, i) => (
                <li key={i}>{obj.name}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* BACK BUTTON */}
      <button className="back-btn" onClick={() => navigate(-1)}>
        ← Back
      </button>

      {/* EDIT MODAL */}
      <ItineraryForm
        visible={showEditModal}
        initialValues={itinerary}
        onSubmit={handleUpdate}
        onClose={() => setShowEditModal(false)}
      />
    </div>
  );
}
