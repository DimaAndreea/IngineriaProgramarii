package com.travelquest.travelquestbackend.model;

import jakarta.persistence.*;
import java.time.ZonedDateTime;

@Entity
@Table(
        name = "user_missions",
        uniqueConstraints = @UniqueConstraint(columnNames = {"mission_id", "user_id"})
)
public class MissionParticipation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_mission_id") // corespunde bazei
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "mission_id", nullable = false)
    private Mission mission;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "state", nullable = false) // corespunde bazei (IN_PROGRESS, COMPLETED, CLAIMED)
    private MissionParticipationStatus status = MissionParticipationStatus.IN_PROGRESS;

    @Column(name = "progress_value", nullable = false) // corespunde bazei
    private int progress = 0; // 0–100 %

    @Column(name = "started_at", nullable = false) // corespunde bazei
    private ZonedDateTime createdAt = ZonedDateTime.now();

    @Column(name = "completed_at")
    private ZonedDateTime completedAt;

    @Column(name = "claimed_at")
    private ZonedDateTime claimedAt;

    @Column(name = "anchor_itinerary_id") // opțional, pentru misiuni "same itinerary"
    private Long anchorItineraryId;

    // ======================
    // Getters & Setters
    // ======================

    public Long getId() { return id; }

    public Mission getMission() { return mission; }
    public void setMission(Mission mission) { this.mission = mission; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public MissionParticipationStatus getStatus() { return status; }
    public void setStatus(MissionParticipationStatus status) { this.status = status; }

    public int getProgress() { return progress; }
    public void setProgress(int progress) { this.progress = progress; }

    public ZonedDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(ZonedDateTime createdAt) { this.createdAt = createdAt; }

    public ZonedDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(ZonedDateTime completedAt) { this.completedAt = completedAt; }

    public ZonedDateTime getClaimedAt() { return claimedAt; }
    public void setClaimedAt(ZonedDateTime claimedAt) { this.claimedAt = claimedAt; }

    public Long getAnchorItineraryId() { return anchorItineraryId; }
    public void setAnchorItineraryId(Long anchorItineraryId) { this.anchorItineraryId = anchorItineraryId; }
}
