package com.travelquest.travelquestbackend.controller;

import com.travelquest.travelquestbackend.dto.MissionDto;
import com.travelquest.travelquestbackend.dto.RewardDto;
import com.travelquest.travelquestbackend.model.Mission;
import com.travelquest.travelquestbackend.model.MissionParticipation;
import com.travelquest.travelquestbackend.model.Reward;
import com.travelquest.travelquestbackend.repository.MissionParticipationRepository;
import com.travelquest.travelquestbackend.service.MissionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/missions")
public class MissionController {

    private final MissionService missionService;
    private final MissionParticipationRepository participationRepository;

    public MissionController(
            MissionService missionService,
            MissionParticipationRepository participationRepository
    ) {
        this.missionService = missionService;
        this.participationRepository = participationRepository;
    }

    // ===============================
    // LIST MISSIONS (FRONTEND)
    // ===============================
    @GetMapping
    public ResponseEntity<List<MissionForUserDto>> getAllMissions(
            @RequestParam(required = false) Long userId
    ) {
        Iterable<Mission> iterable = missionService.getAllMissions();

        List<MissionForUserDto> result = new ArrayList<>();

        for (Mission mission : iterable) {
            MissionForUserDto dto = new MissionForUserDto();

            dto.setId(mission.getId());
            dto.setTitle(mission.getTitle());
            dto.setDescription(mission.getDescription());
            dto.setRole(mission.getRole());
            dto.setType(mission.getType());
            dto.setTarget(mission.getTargetValue());

            // ===== Reward =====
            Reward reward = mission.getReward();
            if (reward != null) {
                RewardDto rewardDto = new RewardDto();
                rewardDto.setRewardLabel(reward.getTitle());
                rewardDto.setXpReward(reward.getXpReward());
                rewardDto.setDescription(reward.getDescription());
                dto.setReward(rewardDto);
            }

            // ===== User-specific data =====
            if (userId != null) {
                Optional<MissionParticipation> participation =
                        participationRepository.findByMission_IdAndUser_Id(
                                mission.getId(), userId
                        );

                if (participation.isPresent()) {
                    MissionParticipation mp = participation.get();
                    dto.setMyProgress(mp.getProgress());
                    dto.setMyStatus(mp.getStatus().name());
                    dto.setClaimedAt(mp.getClaimedAt()); // ZonedDateTime ✔
                } else {
                    dto.setMyProgress(0);
                    dto.setMyStatus("PENDING");
                }
            }

            result.add(dto);
        }

        return ResponseEntity.ok(result);
    }

    // ===============================
    // CREATE MISSION
    // ===============================
    @PostMapping
    public ResponseEntity<Mission> createMission(
            @RequestBody @Valid MissionDto dto
    ) {
        Long adminId = 1L; // MOCK
        Mission mission = missionService.createMission(dto, adminId);
        return ResponseEntity.status(HttpStatus.CREATED).body(mission);
    }

    // ===============================
    // MISSION METADATA
    // ===============================
    @GetMapping("/meta")
    public ResponseEntity<?> getMissionMeta() {
        return ResponseEntity.ok(
                Map.of(
                        "roles", List.of("TOURIST", "GUIDE"),
                        "types", List.of(
                                Map.of(
                                        "value", "GUIDE_PUBLISH_ITINERARY_COUNT",
                                        "role", "GUIDE",
                                        "label", "Publish itineraries",
                                        "paramsSchema", Map.of()
                                ),
                                Map.of(
                                        "value", "TOURIST_JOIN_ITINERARY_COUNT",
                                        "role", "TOURIST",
                                        "label", "Join itineraries",
                                        "paramsSchema", Map.of()
                                )
                        ),
                        "categories", List.of(
                                "History", "Art", "Nature", "Food", "Adventure"
                        )
                )
        );
    }

    // ===============================
    // DTO FOR FRONTEND
    // ===============================
    public static class MissionForUserDto {

        private Long id;
        private String title;
        private String description;
        private String role;
        private String type;
        private int target;

        private int myProgress;
        private String myStatus;
        private ZonedDateTime claimedAt;

        private RewardDto reward;

        // ===== Getters & Setters =====
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }

        public String getType() { return type; }
        public void setType(String type) { this.type = type; }

        public int getTarget() { return target; }
        public void setTarget(int target) { this.target = target; }

        public int getMyProgress() { return myProgress; }
        public void setMyProgress(int myProgress) { this.myProgress = myProgress; }

        public String getMyStatus() { return myStatus; }
        public void setMyStatus(String myStatus) { this.myStatus = myStatus; }

        public ZonedDateTime getClaimedAt() { return claimedAt; }
        public void setClaimedAt(ZonedDateTime claimedAt) { this.claimedAt = claimedAt; }

        public RewardDto getReward() { return reward; }
        public void setReward(RewardDto reward) { this.reward = reward; }
    }
}
