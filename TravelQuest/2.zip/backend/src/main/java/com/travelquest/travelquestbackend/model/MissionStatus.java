package com.travelquest.travelquestbackend.model;

public enum MissionStatus {
    ACTIVE,
    EXPIRED,
    DRAFT
}
