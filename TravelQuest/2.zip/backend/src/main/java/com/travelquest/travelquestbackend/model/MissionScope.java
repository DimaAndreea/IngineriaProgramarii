package com.travelquest.travelquestbackend.model;

public enum MissionScope {
    BOTH,
    TOURIST,
    GUIDE
}