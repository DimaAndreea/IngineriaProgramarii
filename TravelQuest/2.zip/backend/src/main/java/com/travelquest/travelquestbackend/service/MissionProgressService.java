package com.travelquest.travelquestbackend.service;

import com.travelquest.travelquestbackend.dto.RewardDto;
import com.travelquest.travelquestbackend.model.Mission;
import com.travelquest.travelquestbackend.model.MissionParticipation;
import com.travelquest.travelquestbackend.model.MissionParticipationStatus;
import com.travelquest.travelquestbackend.model.Reward;
import com.travelquest.travelquestbackend.model.SubmissionStatus;
import com.travelquest.travelquestbackend.repository.ItineraryRepository;
import com.travelquest.travelquestbackend.repository.MissionParticipationRepository;
import com.travelquest.travelquestbackend.repository.ObjectiveSubmissionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class MissionProgressService {

    private static final Logger logger = LoggerFactory.getLogger(MissionProgressService.class);

    private final MissionParticipationRepository participationRepository;
    private final ObjectiveSubmissionRepository submissionRepository;
    private final ItineraryRepository itineraryRepository;

    public MissionProgressService(
            MissionParticipationRepository participationRepository,
            ObjectiveSubmissionRepository submissionRepository,
            ItineraryRepository itineraryRepository
    ) {
        this.participationRepository = participationRepository;
        this.submissionRepository = submissionRepository;
        this.itineraryRepository = itineraryRepository;
    }

    // ============================================================
    // SCHEDULER
    // ============================================================
    @Scheduled(fixedRate = 10000)
    public void updateAllMissionsProgressLoop() {
        List<MissionParticipation> participations =
                participationRepository.findByStatusIn(List.of(MissionParticipationStatus.IN_PROGRESS));

        for (MissionParticipation mp : participations) {
            try {
                updateProgress(mp.getUser().getId(), mp.getMission().getId());
            } catch (Exception e) {
                logger.error(
                        "Failed to update progress for user {} mission {}",
                        mp.getUser().getId(),
                        mp.getMission().getId(),
                        e
                );
            }
        }
    }

    // ============================================================
    // CORE LOGIC
    // ============================================================
    @Transactional
    public RewardDto updateProgress(Long userId, Long missionId) {

        logger.info("➡️ updateProgress START userId={}, missionId={}", userId, missionId);

        MissionParticipation participation =
                participationRepository.findByMission_IdAndUser_Id(missionId, userId)
                        .orElseThrow(() -> new IllegalStateException("MissionParticipation not found"));

        logger.debug("Participation status BEFORE: {}", participation.getStatus());

        if (participation.getStatus() != MissionParticipationStatus.IN_PROGRESS) {
            logger.debug("⏭️ Participation not IN_PROGRESS → skipping");
            return null;
        }

        Mission mission = participation.getMission();

        int currentValue = calculateCurrentValue(userId, mission);
        int targetValue = mission.getTargetValue();
        int progressPercent = calculateProgressPercent(currentValue, targetValue);

        logMissionProgress(userId, mission, currentValue, targetValue, progressPercent);

        participation.setProgress(progressPercent);

        RewardDto rewardDto = null;

        // ============================================================
        // MISSION COMPLETED
        // ============================================================
        if (currentValue >= targetValue) {

            logger.info("🎉 Mission COMPLETED detected for user={}, mission='{}'",
                    userId, mission.getTitle());

            participation.setStatus(MissionParticipationStatus.COMPLETED);
            participation.setCompletedAt(ZonedDateTime.now());

            Reward reward = mission.getReward();

            // 🔍 LOGURI REWARD
            if (reward == null) {
                logger.warn("⚠️ Mission '{}' has NO reward attached!", mission.getTitle());
            } else {
                logger.info("🎁 Reward FOUND for mission '{}'", mission.getTitle());
                logger.info("   ↳ rewardId       = {}", reward.getId());
                logger.info("   ↳ rewardTitle    = {}", reward.getTitle());
                logger.info("   ↳ xpReward       = {}", reward.getXpReward());
                logger.info("   ↳ description    = {}", reward.getDescription());

                rewardDto = new RewardDto();
                rewardDto.setId(reward.getId());
                rewardDto.setRewardLabel(reward.getTitle());
                rewardDto.setXpReward(reward.getXpReward());
                rewardDto.setDescription(reward.getDescription());

                logger.info("✅ RewardDto CREATED");
                logger.info("   ↳ dto.id         = {}", rewardDto.getId());
                logger.info("   ↳ dto.label      = {}", rewardDto.getRewardLabel());
                logger.info("   ↳ dto.xpReward   = {}", rewardDto.getXpReward());
                logger.info("   ↳ dto.description= {}", rewardDto.getDescription());
            }

        } else {
            participation.setStatus(MissionParticipationStatus.IN_PROGRESS);
            logger.debug("Mission still IN_PROGRESS");
        }

        participationRepository.save(participation);

        logger.info("⬅️ updateProgress END → returning rewardDto = {}",
                rewardDto != null ? "NOT NULL" : "NULL");

        return rewardDto;
    }



    // ============================================================
    // CURRENT VALUE CALCULATION
    // ============================================================
    private int calculateCurrentValue(Long userId, Mission mission) {
        return switch (mission.getType()) {
            case "TOURIST_JOIN_ITINERARY_COUNT" ->
                    itineraryRepository.countUserJoinedItineraries(userId);

            case "TOURIST_APPROVED_SUBMISSIONS_COUNT" ->
                    (int) submissionRepository.countByTouristAndStatus(userId, SubmissionStatus.APPROVED);

            case "GUIDE_PUBLISH_ITINERARY_COUNT" ->
                    itineraryRepository.countPublishedByUser(userId);

            case "GUIDE_EVALUATE_SUBMISSIONS_COUNT" ->
                    (int) submissionRepository.countEvaluatedByGuide(userId);

            default -> {
                logger.warn("Unknown mission type: {}", mission.getType());
                yield 0;
            }
        };
    }

    // ============================================================
    // HELPERS
    // ============================================================
    private int calculateProgressPercent(int current, int target) {
        if (target <= 0) return 0;
        return Math.min(100, (current * 100) / target);
    }

    private void logMissionProgress(Long userId, Mission mission, int currentValue, int targetValue, int progressPercent) {
        logger.info("""
                \n=== USER MISSION PROGRESS ===
                User ID: {}
                Mission: '{}' ({})
                Current: {}
                Target: {}
                Progress: {}%
                =============================""",
                userId, mission.getTitle(), mission.getType(), currentValue, targetValue, progressPercent
        );
    }
}
