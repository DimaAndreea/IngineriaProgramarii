package com.travelquest.travelquestbackend.service;

import com.travelquest.travelquestbackend.dto.MissionParticipationDto;
import com.travelquest.travelquestbackend.dto.RewardDto;
import com.travelquest.travelquestbackend.model.GamifiedActionType;
import com.travelquest.travelquestbackend.model.Mission;
import com.travelquest.travelquestbackend.model.MissionParticipation;
import com.travelquest.travelquestbackend.model.MissionParticipationStatus;
import com.travelquest.travelquestbackend.model.User;
import com.travelquest.travelquestbackend.model.UserPointsHistory;
import com.travelquest.travelquestbackend.repository.MissionParticipationRepository;
import com.travelquest.travelquestbackend.repository.MissionRepository;
import com.travelquest.travelquestbackend.repository.UserPointsHistoryRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.List;

@Service
public class MissionParticipationService {

    private final MissionRepository missionRepository;
    private final MissionParticipationRepository participationRepository;
    private final UserPointsHistoryRepository pointsHistoryRepository;

    public MissionParticipationService(
            MissionRepository missionRepository,
            MissionParticipationRepository participationRepository,
            UserPointsHistoryRepository pointsHistoryRepository
    ) {
        this.missionRepository = missionRepository;
        this.participationRepository = participationRepository;
        this.pointsHistoryRepository = pointsHistoryRepository;
    }

    // ===============================
    // JOIN MISSION
    // ===============================
    @Transactional
    public MissionParticipationDto joinMission(Long missionId, User user) {

        Mission mission = missionRepository.findById(missionId)
                .orElseThrow(() -> new EntityNotFoundException("Mission not found"));

        if (!mission.getRole().equalsIgnoreCase(user.getRole().name())) {
            throw new IllegalArgumentException(
                    "User role (" + user.getRole() + ") cannot join mission for role " + mission.getRole()
            );
        }

        boolean alreadyJoined = participationRepository.existsByMissionAndUser(mission, user);
        if (alreadyJoined) {
            throw new IllegalArgumentException("User already joined this mission");
        }

        MissionParticipation participation = new MissionParticipation();
        participation.setMission(mission);
        participation.setUser(user);
        participation.setStatus(MissionParticipationStatus.IN_PROGRESS);
        participation.setProgress(0);
        participation.setCreatedAt(ZonedDateTime.now());

        participationRepository.save(participation);

        System.out.println("=== USER JOINED MISSION ===");
        System.out.println("User ID: " + user.getId() + ", Role: " + user.getRole());
        System.out.println("Mission ID: " + mission.getId() + ", Title: " + mission.getTitle());
        System.out.println("Status: " + participation.getStatus());
        System.out.println("Progress: " + participation.getProgress() + "%");
        System.out.println("Reward Points (to be claimed): " + mission.getRewardPoints());
        System.out.println("============================");

        return new MissionParticipationDto(
                mission.getId(),
                user.getId(),
                participation.getStatus().name(),
                participation.getProgress(),
                0
        );
    }

    // ===============================
    // CLAIM MISSION
    // ===============================
    @Transactional
    public RewardDto claimMission(Long missionId, User user) {

        MissionParticipation participation = participationRepository
                .findByMission_IdAndUser_Id(missionId, user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Mission participation not found"));

        if (participation.getStatus() != MissionParticipationStatus.COMPLETED) {
            throw new IllegalStateException("Mission not completed yet");
        }

        Mission mission = participation.getMission();

        if (mission.getReward() == null) {
            throw new IllegalStateException("Completed mission has no reward");
        }

        participation.setStatus(MissionParticipationStatus.CLAIMED);
        participation.setClaimedAt(ZonedDateTime.now());
        participationRepository.save(participation);

        // ✅ aplicăm reward-ul, nu îl calculăm
        UserPointsHistory history = new UserPointsHistory();
        history.setUser(user);
        history.setPointsDelta(mission.getReward().getXpReward());
        history.setActionType(GamifiedActionType.OBJECTIVE_APPROVED);
        history.setObjectiveId(mission.getId());
        pointsHistoryRepository.save(history);

        // ✅ doar mapare simplă
        RewardDto reward = new RewardDto();
        reward.setId(mission.getReward().getId());
        reward.setRewardLabel(mission.getReward().getTitle());
        reward.setXpReward(mission.getReward().getXpReward());
        reward.setDescription(mission.getReward().getDescription());

        return reward;
    }


    // ===============================
    // GET MY REWARDS (COMPLETED & CLAIMED)
    // ===============================
    public List<MissionParticipationDto> getMyRewards(User user) {

        List<MissionParticipation> participations = participationRepository
                .findByUserAndStatusIn(user, List.of(MissionParticipationStatus.COMPLETED, MissionParticipationStatus.CLAIMED));

        System.out.println("=== USER REWARDS ===");
        System.out.println("User ID: " + user.getId());
        for (MissionParticipation p : participations) {
            System.out.println("Mission: " + p.getMission().getTitle() +
                    ", XP: " + p.getMission().getRewardPoints() +
                    ", Status: " + p.getStatus() +
                    ", Progress: " + p.getProgress() + "%" +
                    ", Description: " + (p.getMission().getReward() != null ? p.getMission().getReward().getDescription() : "null"));
        }
        System.out.println("===================");

        return participations.stream()
                .map(p -> new MissionParticipationDto(
                        p.getMission().getId(),
                        user.getId(),
                        p.getStatus().name(),
                        p.getProgress(),
                        p.getMission().getRewardPoints()
                ))
                .toList();
    }
}
