package com.travelquest.travelquestbackend.model;

public enum ItineraryCategory {
    CULTURAL,
    ADVENTURE,
    CITY_BREAK,
    ENTERTAINMENT,
    EXOTIC
}
