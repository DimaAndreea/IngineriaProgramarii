package com.travelquest.travelquestbackend.service;

import com.travelquest.travelquestbackend.dto.MissionDto;
import com.travelquest.travelquestbackend.dto.RewardDto;
import com.travelquest.travelquestbackend.model.Mission;
import com.travelquest.travelquestbackend.model.MissionScope;
import com.travelquest.travelquestbackend.model.MissionStatus;
import com.travelquest.travelquestbackend.model.Reward;
import com.travelquest.travelquestbackend.repository.MissionRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;

@Service
public class MissionService {

    private static final Logger log = LoggerFactory.getLogger(MissionService.class);

    private final MissionRepository missionRepository;
    private final ObjectMapper objectMapper;

    public MissionService(MissionRepository missionRepository, ObjectMapper objectMapper) {
        this.missionRepository = missionRepository;
        this.objectMapper = objectMapper;
    }

    public Iterable<Mission> getAllMissions() {
        return missionRepository.findAll();
    }

    public Mission createMission(MissionDto dto, Long creatorId) {

        log.info("🛠️ Creating mission: title='{}', role={}, type={}",
                dto.getTitle(), dto.getRole(), dto.getType());

        Mission mission = new Mission();
        mission.setTitle(dto.getTitle());
        mission.setDescription(dto.getDescription());
        mission.setCreatorId(creatorId);

        // ===============================
        // Parse start_at / end_at
        // ===============================
        if (dto.getStartAt() != null) {
            mission.setStartAt(ZonedDateTime.parse(dto.getStartAt()).toLocalDateTime());
        }
        if (dto.getEndAt() != null) {
            mission.setEndAt(ZonedDateTime.parse(dto.getEndAt()).toLocalDateTime());
        } else {
            mission.setEndAt(LocalDateTime.now().plusDays(7));
        }

        mission.setRole(dto.getRole());
        mission.setType(dto.getType());
        mission.setTargetValue(dto.getTargetValue());

        // ===============================
        // Params
        // ===============================
        if (dto.getParams() != null && !dto.getParams().isEmpty()) {
            try {
                mission.setParamsJson(objectMapper.writeValueAsString(dto.getParams()));
            } catch (JsonProcessingException e) {
                throw new IllegalArgumentException("Invalid params JSON", e);
            }
        }

        // ===============================
        // Reward
        // ===============================
        if (dto.getReward() != null) {

            log.info("🎁 Creating reward for mission '{}'", dto.getTitle());
            log.info("   ↳ rewardLabel='{}'", dto.getReward().getRewardLabel());
            log.info("   ↳ xpReward={}", dto.getReward().getXpReward());
            log.info("   ↳ description='{}'", dto.getReward().getDescription());

            Reward reward = new Reward();

            reward.setXpReward(dto.getReward().getXpReward());
            reward.setTitle(
                    dto.getReward().getRewardLabel() != null
                            ? dto.getReward().getRewardLabel()
                            : "Voucher"
            );
            reward.setDescription(dto.getReward().getDescription());

            reward.setMission(mission);
            mission.setReward(reward);

            mission.setRewardPoints(dto.getReward().getXpReward());

        } else {
            log.warn("⚠️ Mission '{}' created WITHOUT reward", dto.getTitle());
            mission.setRewardPoints(0);
        }

        // ===============================
        // Status & scope
        // ===============================
        mission.setStatus(MissionStatus.DRAFT);
        mission.setScope(MissionScope.BOTH);

        Mission saved = missionRepository.save(mission);

        log.info("✅ Mission saved: id={}, rewardId={}",
                saved.getId(),
                saved.getReward() != null ? saved.getReward().getId() : null
        );

        return saved;
    }

    // ===============================
    // Reward → DTO mapping
    // ===============================
    public RewardDto mapRewardToDto(Reward reward) {
        if (reward == null) {
            log.warn("⚠️ mapRewardToDto called with NULL reward");
            return null;
        }

        log.info("🎯 Mapping Reward → DTO");
        log.info("   ↳ rewardId={}", reward.getId());
        log.info("   ↳ title='{}'", reward.getTitle());
        log.info("   ↳ xpReward={}", reward.getXpReward());
        log.info("   ↳ description='{}'", reward.getDescription());

        RewardDto dto = new RewardDto();
        dto.setId(reward.getId());
        dto.setRewardLabel(reward.getTitle());
        dto.setXpReward(reward.getXpReward());
        dto.setDescription(reward.getDescription());

        return dto;
    }
}
