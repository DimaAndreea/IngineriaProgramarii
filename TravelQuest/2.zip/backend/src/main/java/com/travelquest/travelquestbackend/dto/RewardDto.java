package com.travelquest.travelquestbackend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.ZonedDateTime;

public class RewardDto {

    private Long id;

    @JsonProperty("reward_label")
    private String rewardLabel;       // maps mission_rewards.real_reward_title

    @JsonProperty("xp_reward")
    private int xpReward;

    @JsonProperty("description")
    private String description; // real_reward_description

    @JsonProperty("claimed_at")
    private ZonedDateTime claimedAt;

    @JsonProperty("mission_title")
    private String missionTitle;

    // =========================
    // Getters & Setters
    // =========================
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRewardLabel() { return rewardLabel; }
    public void setRewardLabel(String rewardLabel) { this.rewardLabel = rewardLabel; }

    public int getXpReward() { return xpReward; }
    public void setXpReward(int xpReward) { this.xpReward = xpReward; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public ZonedDateTime getClaimedAt() { return claimedAt; }
    public void setClaimedAt(ZonedDateTime claimedAt) { this.claimedAt = claimedAt; }

    public String getMissionTitle() { return missionTitle; }
    public void setMissionTitle(String missionTitle) { this.missionTitle = missionTitle; }
}
