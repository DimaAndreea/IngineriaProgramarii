package com.travelquest.travelquestbackend.model;

public enum ItineraryStatus {
    PENDING,
    APPROVED,
    REJECTED
}
