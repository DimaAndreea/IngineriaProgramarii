package com.travelquest.travelquestbackend.model;

public enum MissionParticipationStatus {
    IN_PROGRESS,   // corespunde valorii default din baza de date
    COMPLETED,
    CLAIMED
}
