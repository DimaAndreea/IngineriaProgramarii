package com.travelquest.travelquestbackend.model;

public enum WalletTxType {
    TOPUP,
    PURCHASE,
    ADJUSTMENT,
    REFUND
}
