package com.travelquest.travelquestbackend.model;

public enum SubmissionStatus {
    PENDING,
    APPROVED,
    REJECTED
}
