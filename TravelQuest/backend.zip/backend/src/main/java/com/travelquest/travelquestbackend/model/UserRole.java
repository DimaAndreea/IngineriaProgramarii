package com.travelquest.travelquestbackend.model;

public enum UserRole {
    TOURIST,
    GUIDE,
    ADMIN
}
