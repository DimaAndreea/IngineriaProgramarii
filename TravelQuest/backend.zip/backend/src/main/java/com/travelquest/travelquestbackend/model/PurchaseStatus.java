package com.travelquest.travelquestbackend.model;

public enum PurchaseStatus {
    PENDING,
    PAID,
    FAILED,
    REFUNDED,
    CANCELLED
}
