package com.travelquest.travelquestbackend.dto;

import lombok.Data;

@Data
public class ObjectiveDto {
    private String name;
}
